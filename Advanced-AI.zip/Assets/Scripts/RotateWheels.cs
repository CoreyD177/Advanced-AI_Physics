using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateWheels : MonoBehaviour
{
    private HingeJoint frontJoint;
    private JointMotor frontSteer;
    private HingeJoint backJoint;
    private JointMotor backSteer;
    private HingeJoint forwardDrive;
    private JointMotor forwardMotor;
    private HingeJoint rearDrive;
    private JointMotor backMotor;
    private void Start()
    {
        frontJoint = GetComponent<HingeJoint>();
        backJoint = GameObject.Find("RearConnect").GetComponent<HingeJoint>();
        forwardDrive = GameObject.Find("Wheels01").GetComponent<HingeJoint>();
        rearDrive = GameObject.Find("Wheels02").GetComponent<HingeJoint>();
        forwardMotor = forwardDrive.motor;
        backMotor = rearDrive.motor;
        frontSteer = frontJoint.motor;
        backSteer = backJoint.motor;
    }
    void Update()
    {
        if (Input.GetKey(KeyCode.W))
        {
            forwardDrive.useMotor = true;
            rearDrive.useMotor = true;
            forwardMotor.targetVelocity = 500f;
            backMotor.targetVelocity = 500f;
            forwardDrive.motor = forwardMotor;
            rearDrive.motor = backMotor;
        }
        else if (Input.GetKey(KeyCode.S))
        {
            forwardDrive.useMotor = true;
            rearDrive.useMotor = true;
            forwardMotor.targetVelocity = -500f;
            backMotor.targetVelocity = -500f;
            forwardDrive.motor = forwardMotor;
            rearDrive.motor = backMotor;
        }
        else
        {
            forwardDrive.useMotor = false;
            rearDrive.useMotor = false;
        }
        if (Input.GetKey(KeyCode.A))
        {
            frontJoint.useMotor = true;
            backJoint.useMotor = true;
            frontSteer.targetVelocity = -200f;
            backSteer.targetVelocity = 100f;
            frontJoint.motor = frontSteer;
            backJoint.motor = backSteer;
        }
        else if (Input.GetKey(KeyCode.D))
        {
            frontJoint.useMotor = true;
            backJoint.useMotor = true;
            frontSteer.targetVelocity = 200f;
            backSteer.targetVelocity = -100f;
            frontJoint.motor = frontSteer;
            backJoint.motor = backSteer;
        }
        else
        {
            frontJoint.useMotor = false;
            backJoint.useMotor = false;
        }
    }
}
